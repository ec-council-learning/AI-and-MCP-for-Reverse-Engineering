#include <stdio.h>
#include <string.h>

int main()
{
	char serial[50];
	const char correctSerial[] = "abc-123456";

	printf("Enter serial key: ");
	scanf("%49s", serial);

	if(strcmp(serial, correctSerial)==0){
		printf("Correct\n");
	}else{
		printf("Wrong serial\n");
	}

	return 0;

}
